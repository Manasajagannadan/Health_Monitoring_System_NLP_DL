from NaiveBayes import  Pool
import os
DClasses = ["a","allergies","c","f","h","s","u"]
f="plz"
base = "learn/"
p = Pool()
for i in DClasses:
    print(i)
    p.learn(base + i, i)
base = "test/"
print("enter the problem u have")
s=input("enter here: ")
text_file=open("test/plz/ot.txt","w")
text_file.write(s)
#text_file.write()
text_file.close()
for i in range(0,10,1):
   #text_file("\n")
   #s=input("enter here: ")
   #text_file.write(new)
   #text_file.close()
#for i in DClasses:
    #dir = os.listdir(base + i)
    #for file in dir:
        #res = p.Probability(base + i + "/" + file)
        #print(i + ": " + file + ": " + str(res))
   dir = os.listdir(base + f)
   for file in dir:
      res = p.Probability(base + f + "/" + file)
      if(file=="ot.txt"):
        print(f + ": " + file + ": " +str(res))
        req=str(res[0])
        print(req[2])
        #text = open("learn/fever/fChatbot.txt","r", encoding='utf-8').read()
        #except UnicodeDecodeError:
            #text = open(learn/fever,"r", encoding='latin-1').read()
        #text = text.lower()
        #print(text)
        #content=text.readlines()
              #with open("learn/fever/fChatbot.txt","r") as f:
                 #content=f.readlines()
              #print (content)
        count_n=0
        for i in range(0,4,1):
           fp=open('learn/f/fChatbot.txt')
           lines=fp.read().split("\n")
           print(lines[i])
           in1=input("enter here: y/n")
           if(in1=='n'):
                count_n +=1
        if(count_n<=1):	
            print("fever")
            exit()
        else:
           l='learn/'
           c="Chatbot.txt"
           k=str(res[1])
           k2=k[2]
           k1=k2+c
           print(k1)
           for i in range(0,4,1):
              fp=open(l+k2+"/"+k1)
              lines=fp.read().split("\n")
              print(lines[i])
              new=lines[i]
              in1=input("enter here: y/n")
              if(in1=='y'):
                text_file=open("test/plz/ot.txt","w")
                text_file.write(new)
                break
        break
                 
