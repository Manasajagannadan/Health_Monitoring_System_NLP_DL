from NaiveBayes import  Pool
import os
import pyttsx3
import random
import time
import speech_recognition as sr
import random
import time
import speech_recognition as sr
DClasses = ["a","allergies","c","f","h","s","u"]
f="plz"
base = "learn/"
p = Pool()
for i in DClasses:
    print(i)
    p.learn(base + i, i)
base = "test/"
print("Enter what is your problem: ")
s=input("enter here: ")
////////////////////////////////////
text_file=open("test/plz/ot.txt","w")
#text_file1=open("test/plz/ot1.html","w")
text_file.write(s)
#text_file1.write(s)
text_file.close()
#text_file.write()
text_file.close()
for i in range(0,5,1):
  with open("test/plz/ot.txt","a") as text_file:
   text_file.write('\n')
   dir = os.listdir(base + f)
   for file in dir:
      res = p.Probability(base + f + "/" + file)
      if(file=="ot.txt"):
        print(f + ": " + file + ": " +str(res))
        req=str(res[0])
        print(req[2])
        count_n=0
        for i in range(0,3,1):
           l='learn/'
           c="Chatbot.txt"
           manu=str(res[0])
           k2=manu[2]
           k1=k2+c
           print(k1)
           fp=open(l+k2+"/"+k1)
           lines=fp.read().split("\n")
           print(lines[i])
           //////////////////////
           engine = pyttsx3.init()
           k=''
           #k=input('enter the text u want to speak out')
           k=lines[i]
           engine.say(k)
           engine.setProperty('rate',45)
           engine.setProperty('volume', 5)
           engine.runAndWait()
           in1=input("Enter here: y/n")
           if(in1=='n'):
                count_n +=1
        if(count_n<=1):	
            print(manu[2])
            m3=manu[2]
            exit()
        else:
           l='learn/'
           c="Chatbot.txt"
           manu=str(res[1])
           k2=manu[2]
           k1=k2+c
           print(k1)
           count_n1=0
           for i in range(0,3,1):
              fp=open(l+k2+"/"+k1)
              lines=fp.read().split("\n")
              newQ=" "
              print(lines[i])
              ///////////////////
              engine = pyttsx3.init()
              k=''
              #k=input('enter the text u want to speak out')
              k=lines[i]
              engine.say(k)
              engine.setProperty('rate',45)
              engine.setProperty('volume', 5)
              engine.runAndWait()
              new=lines[i]
              in1=input("Enter here: y/n")
              if(in1=='y'):
                for i in range(10,len(new),1):
                     newQ=newQ+new[i]
                print(newQ)
                text_file=open("test/plz/ot.txt","a")
                text_file.write(newQ)
                break
              count_n1 +=1
           if(count_n1!=0):
            new1=input("Please Enter one of your symptoms: ")
            ///////////////////////////////
            #print("Please Enter one of your symptoms: ")
            text_file=open("test/plz/ot.txt","a")
            text_file.write(new1)
                 
